function message() {
    document.getElementById("messages").style.display = "flex"; 
}

function closemessage() {
    document.getElementById("messages").style.display = "none";
}